package com.example.zookotlin

import android.app.Application
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.zookotlin.fragment.HomeFragment

// 負責做跳頁
class MyApplication : Application() {
    private lateinit var mFragmentManager: FragmentManager
    private var mNowFragment: Fragment? = null
    var mIsOpenInOutDoor: Boolean = false

    fun setFragmentManager(pFragmentManager: FragmentManager) {
        mFragmentManager = pFragmentManager
    }

//    fun setGoToOtherPageData(pTargetFragment: Fragment, pHomePageTitle: String?) {
//        val iBundle = Bundle()
//        iBundle.putString(Parameter.mKeyHomePageTitle, pHomePageTitle)// 標題
////        pTargetFragment.arguments = iBundle
//        goToNextPage(pTargetFragment, iBundle)
//    }

    // 去下一頁
    private fun goToNextPage(pTargetFragment: Fragment, pBundle: Bundle?) {

        mNowFragment = pTargetFragment
        val iNowFragment = mNowFragment // Home, List,
        Log.v("aaa", "fragments  = " + mFragmentManager.fragments.size)

        //TODO: 這 iFragment 都是HomeFragment --> 寫三個 if 讓他判斷
        for (iFragment in mFragmentManager.fragments) {
            val iTag = iFragment.tag //  Home,
            Log.v("aaa", "GotoPage iTag = " + iTag + ", isHidden =" + iFragment.isHidden)

            if (iTag != null) {
                if (iTag != "com.bumptech.glide.manager") {
                    mNowFragment = iFragment
                }
            }
//            if (iFragment != null && (iTag == HomeFragment::class.java.simpleName) && (!iFragment.isHidden)) {
//                mNowFragment = iFragment
//                break
//            }
//            if (iFragment != null && (iTag == ListFragment::class.java.simpleName) && (!iFragment.isHidden)) {
//                mNowFragment = iFragment
//                break
//            }
//            if (iFragment != null && (iTag == DetailFragment::class.java.simpleName) && (!iFragment.isHidden)) {
//                mNowFragment = iFragment
//                break
//            }
            Log.v("aaa", "GotoPage_getFragments_size    =" + mFragmentManager.fragments.size)
        }


        Log.i("aaa", "GoToPage_iNowFragment = $iNowFragment")
        if (iNowFragment != null) // 目前要去的頁面
        {
            mFragmentManager.beginTransaction()
                .add(
                    R.id.fragment_container_view,
                    pTargetFragment::class.java, pBundle,
                    pTargetFragment::class.java.simpleName // pTargetFragment.javaClass.simpleName
                )
                .hide(mNowFragment!!)// 目前要hide掉的頁面
                .addToBackStack(null) // name can be null
                .commit()

            Log.i("aaa", "GoToPage_Hide Fragment tag = " + mNowFragment!!.tag) // 要hide 的Fragment
        }
//        else {
//            mFragmentManager.beginTransaction()
//                .add(
//                    R.id.fragment_container_view,
//                    pTargetFragment::class.java, pBundle,
//                    pTargetFragment::class.java.simpleName // pTargetFragment.javaClass.simpleName
//                )
//                .addToBackStack(null) // name can be null
//                .commit()
//
//            Log.i("aaa", "GoToPage_Hide Fragment tag = " + mNowFragment!!.tag) // 要hide 的Fragment
//        }
    }

    // 返回
    private fun goToPrevPage(keyCode: Int): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {

            if (mFragmentManager.fragments.size != 0) {
                for (ix in mFragmentManager.fragments) {
                    Log.v("aaa", "ix = " + ix.tag + ", ix.isHidden = " + ix.isHidden)
                    if (ix.tag == HomeFragment::class.java.simpleName && !ix.isHidden) {

                        if (mIsOpenInOutDoor) {
                            mIsOpenInOutDoor = false
                            Handler(Looper.getMainLooper()).postDelayed({
                                Log.v("--aaa--", "ccc")

                                goToNextPage(HomeFragment(), null)

                            }, 200)
                            return true
                        } else {
                            return false // 不會返回
                        }
//                          return false // 不會返回
                    }
                }
            }
        }
        return true
    }

    // 多型
    fun goToPage(
        pKeyCode: Int? = null,
        pTargetFragment: Fragment? = null,
        pBundle: Bundle? = null,
    ): Boolean {
        pKeyCode?.let {
            return goToPrevPage(it)
        } ?: kotlin.run {
            pTargetFragment?.let { itF ->
                goToNextPage(itF, pBundle)

            }
        }
        return true
    }
}

