package com.example.zookotlin.fragment

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.integration.okhttp3.OkHttpUrlLoader
import com.bumptech.glide.load.model.GlideUrl
import com.example.zookotlin.*
import com.example.zookotlin.data.detail.DetailData
import com.example.zookotlin.data.detail.ItfDetail
import com.example.zookotlin.databinding.DetailPageBinding
import com.example.zookotlin.util.Parameter
import java.io.InputStream
import java.lang.Exception
import java.util.ArrayList

//TODO：RecyclerView 去做layout
class DetailFragment : BaseFragment<DetailPageBinding, AllViewModel>() {
    private var mAlGeo = ArrayList<String>()


    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    override val mLayout: Int get() = R.layout.detail_page

    override fun uiInit(pTitle: String?) {
        if (pTitle != "") {
            mDataBinding.mToolbar.title = pTitle
            mDataBinding.mToolbar.visibility = View.VISIBLE
//            mGetFcmTitle = ""
//            mGetFcmDetail = ""
//            Log.v("---eee---DetailFragment---FcmTitle FcmAllDetail",
//                "$pTitle, $mGetFcmTitle, $mGetFcmDetail")
        }
        mDataBinding.mToolbar.setNavigationOnClickListener {
            //在Activity下
            requireActivity().onBackPressed()
        }

        initData()
    }

    private fun initData() {
        val iDetailData: ItfDetail? = getApi()
        if (iDetailData != null) { //mAsJsonObject = 詳細內容
            when (mTitle) {
                Parameter.getInstance().mKeyAnimal -> {
                    initAnimalView(iDetailData)
                    initPicUrlView(iDetailData)
                }
                Parameter.getInstance().mKeyPlant -> {
                    initPlantView(iDetailData)
                    initPicUrlView(iDetailData)
                }
                else -> {
                    initAreaView(iDetailData)
                    initPicUrlView(iDetailData)
                }
            }
        }
    }


    private fun initAnimalView(iDetailData: ItfDetail) {
        // 名稱(中、英)、行為、出現地、種類
        // 圖片、影片、位置（文字、url）
        mDataBinding.mAnimalGroupIC.root.visibility = View.VISIBLE
        mDataBinding.mPlantGroupIC.root.visibility = View.GONE
        mDataBinding.mAreaGroupIC.root.visibility = View.GONE
        mDataBinding.mAnimalGroupIC.mTvNameCh.mTvAllZoo.text = iDetailData.getNameCh()
        mDataBinding.mAnimalGroupIC.mTvNameEn.mTvAllZoo.text = iDetailData.getNameEn()
        mDataBinding.mAnimalGroupIC.mTvFamily.mTvAllZoo.text = iDetailData.getFamily()
        mDataBinding.mAnimalGroupIC.mTvAnimalBehavior.mTvAllZoo.text = iDetailData.getABehavior()
        mDataBinding.mAnimalGroupIC.mTvAnimalDistribution.mTvAllZoo.text =
            iDetailData.getADistribution()
        mDataBinding.mAnimalGroupIC.mTvAnimalClass.mTvAllZoo.text = iDetailData.getAClass()
    }

    private fun initPlantView(iDetailData: ItfDetail) {
        // 名稱(中、英)、俗稱、簡介、特徵、種類、應用與使用
        // 圖片、位置（文字、url）
        mDataBinding.mAnimalGroupIC.root.visibility = View.GONE
        mDataBinding.mPlantGroupIC.root.visibility = View.VISIBLE
        mDataBinding.mAreaGroupIC.root.visibility = View.GONE
        mDataBinding.mPlantGroupIC.mTvNameCh.mTvAllZoo.text = iDetailData.getNameCh()
        mDataBinding.mPlantGroupIC.mTvNameEn.mTvAllZoo.text = iDetailData.getNameEn()
        mDataBinding.mPlantGroupIC.mTvFamily.mTvAllZoo.text = iDetailData.getFamily()
        mDataBinding.mPlantGroupIC.mTvAlsoKnown.mTvAllZoo.text = iDetailData.getAlsoKnown()
        mDataBinding.mPlantGroupIC.mTvBrief.mTvAllZoo.text = iDetailData.getBrief()
        mDataBinding.mPlantGroupIC.mTvFeature.mTvAllZoo.text = iDetailData.getFeature()
        mDataBinding.mPlantGroupIC.mTvGenus.mTvAllZoo.text = iDetailData.getGenus()
        if (iDetailData.getFunctionApplication().equals("")) {
            mDataBinding.mPlantGroupIC.mTvFunctionApplication.mTvAllZoo.visibility = View.GONE
            mDataBinding.mPlantGroupIC.mTvFunctionApplicationTitle.visibility = View.GONE
        } else {
            mDataBinding.mPlantGroupIC.mTvFunctionApplication.mTvAllZoo.text =
                iDetailData.getFunctionApplication()
        }
    }

    private fun initAreaView(iDetailData: ItfDetail) {
        // 名稱(中)、資訊
        // 圖片、網站、本館位置（沒有文字地需只有URL）
        mDataBinding.mAnimalGroupIC.root.visibility = View.GONE
        mDataBinding.mPlantGroupIC.root.visibility = View.GONE
        mDataBinding.mAreaGroupIC.root.visibility = View.VISIBLE
        mDataBinding.mAreaGroupIC.mTvNameCh.mTvAllZoo.text = iDetailData.getNameCh()
        mDataBinding.mAreaGroupIC.mTvEInfo.mTvAllZoo.text = iDetailData.getEInfo()
        if (iDetailData.getEMemo().equals("")) {
            mDataBinding.mAreaGroupIC.mTvEMemo.mTvAllZoo.visibility = View.GONE
        } else {
            mDataBinding.mAreaGroupIC.mTvEMemo.mTvAllZoo.setTextColor(Color.parseColor("#FF0000"))
            mDataBinding.mAreaGroupIC.mTvEMemo.mTvAllZoo.text = iDetailData.getEMemo()
        }
    }

    private fun initPicUrlView(iDetailData: ItfDetail) {
        // 圖片
        if (iDetailData.isPicEmpty()) {
            mDataBinding.mPicVideoGroupIC.mTvPicTitle.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mImgPic01URL.mImgAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mImgPic02URL.mImgAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mImgPic03URL.mImgAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mImgPic04URL.mImgAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mTvPic01ALT.mTvAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mTvPic02ALT.mTvAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mTvPic03ALT.mTvAllZoo.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mTvPic04ALT.mTvAllZoo.visibility = View.GONE
        } else {
            selectPicShow(iDetailData.getPic01ALT(),
                iDetailData.getPic01Url(),
                mDataBinding.mPicVideoGroupIC.mTvPic01ALT.mTvAllZoo,
                mDataBinding.mPicVideoGroupIC.mImgPic01URL.mImgAllZoo)
            selectPicShow(iDetailData.getPic02ALT(),
                iDetailData.getPic02URL(),
                mDataBinding.mPicVideoGroupIC.mTvPic02ALT.mTvAllZoo,
                mDataBinding.mPicVideoGroupIC.mImgPic02URL.mImgAllZoo)
            selectPicShow(iDetailData.getPic03ALT(),
                iDetailData.getPic03URL(),
                mDataBinding.mPicVideoGroupIC.mTvPic03ALT.mTvAllZoo,
                mDataBinding.mPicVideoGroupIC.mImgPic03URL.mImgAllZoo)
            selectPicShow(iDetailData.getPic04ALT(),
                iDetailData.getPic04URL(),
                mDataBinding.mPicVideoGroupIC.mTvPic04ALT.mTvAllZoo,
                mDataBinding.mPicVideoGroupIC.mImgPic04URL.mImgAllZoo)
        }

        // 影片
        if (iDetailData.isVideoEmpty()) {
//        if ((iDetailData.getVedioURL() == null) || (iDetailData.getVedioURL().length() == 0)) {
            mDataBinding.mPicVideoGroupIC.mVedioURLTitle.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mVedioURL.mTvAllZoo.visibility = View.GONE
        } else {
            mDataBinding.mPicVideoGroupIC.mVedioURL.mTvAllZoo.setTextColor(Color.parseColor("#4267b2"))
            mDataBinding.mPicVideoGroupIC.mVedioURL.mTvAllZoo.text = "點擊開啟影片"
            mDataBinding.mPicVideoGroupIC.mVedioURL.mTvAllZoo.setOnClickListener {
//                val pIntent = Intent(activity, Video::class.java)
                val iBundle = Bundle()
                iBundle.putString("vedio", iDetailData.getVedioURL())
//                pIntent.putExtras(iBundle)
//                startActivity(pIntent)

                mGoToPageApplication.goToPage(pTargetFragment = VideoFragment(), pBundle = iBundle)
            }
        }

        // 連結
        if (iDetailData.isUrlEmpty()) {
//        if ((iDetailData.getEUrl() == null) || (iDetailData.getEUrl().length() == 0)) {
            mDataBinding.mPicVideoGroupIC.mTvEUrlTitle.visibility = View.GONE
            mDataBinding.mPicVideoGroupIC.mTvEUrl.mTvAllZoo.visibility = View.GONE
        } else {
            mDataBinding.mPicVideoGroupIC.mTvEUrl.mTvAllZoo.setTextColor(Color.parseColor("#4267b2"))
            mDataBinding.mPicVideoGroupIC.mTvEUrl.mTvAllZoo.text = "點擊開啟網頁"
            mDataBinding.mPicVideoGroupIC.mTvEUrl.mTvAllZoo.setOnClickListener {
//                val iIntent = Intent(activity, Video::class.java)
                val iBundle = Bundle()
                iBundle.putString("Url", iDetailData.getEUrl())
//                iIntent.putExtras(iBundle)
//                startActivity(iIntent)
                mGoToPageApplication.goToPage(pTargetFragment = VideoFragment(), pBundle = iBundle)
                Log.v("aaa---Url", iBundle.toString()) //
            }
        }


        // 位置文字
        if (iDetailData.isLocationEmpty()) {
//        if ((iDetailData.getLocation() == null) || (iDetailData.getLocation().length() == 0)) {
            mDataBinding.mPicVideoGroupIC.mTvLoc.root.visibility = View.GONE
        } else {
            mDataBinding.mPicVideoGroupIC.mTvLoc.mTvAllZoo.text = iDetailData.getLocation()
        }


        // 位置URL
        var iArrFGeo = arrayOfNulls<String>(0)
        if (iDetailData.getGeo()?.isNotEmpty() == true) {
            iArrFGeo =
                iDetailData.getGeo()!!
                    .substring(13).replace("),", "").replace("(", "").replace(")", "").split(" ")
                    .toTypedArray()
        }
        //        String[] iArrFGeo = iDetailData.getGeo().substring(13).replace("),", "").replace("(", "").replace(")", "").split(" ");
        val iArrALGeoY = ArrayList<String?>() //
        val iArrALGeoX = ArrayList<String?>()
        val iATempArrList = ArrayList<String?>()


        //----- 不為空白的加進ArrayList裡


        //----- 不為空白的加進ArrayList裡
        for (pStr in iArrFGeo) {
            if (pStr?.trim { it <= ' ' }?.isNotEmpty() == true) {
                iATempArrList.add(pStr)
            }
        }
        val iStrArr = iATempArrList.toTypedArray() //轉成陣列 把空白、多餘的符號清掉

        //----- 區分成X,Y ArrayList來存放
        for (i in iStrArr.indices) {
            if (i % 2 == 0 || i == 0) {
                iArrALGeoY.add(iStrArr[i])
            } else {
                iArrALGeoX.add(iStrArr[i])
            }
        }

//        String pStrGeo = "";
//        SpannableString pSpannableGeo = null;
//        for(int k = 1; k <= pStrArr.length/2 ; k++) {
//            String intro = "點擊開啟位置" + k;
//            pStrGeo = pStrGeo + intro+"\n";
//            pSpannableGeo = new SpannableString(pStrGeo);
//        }
        for (j in 0 until iStrArr.size / 2) {
            val iGeoUrl = iArrALGeoX[j].toString() + "," + iArrALGeoY[j]
            mAlGeo.add(iGeoUrl)
        }

//        for (int j = 0; j < pStrArr.length/2; j++)
//        {
//            if( j < 9)
//            {
//                pSpannableGeo.setSpan(new URLSpan("https://www.google.com/maps/place/"+ iArrALGeoX.get(j) + "," + iArrALGeoY.get(j) ), 0 + 8 * j, 7 + 8 * j, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//0  7 8 15   64  71
//
//            } else{
//                pSpannableGeo.setSpan(new URLSpan("https://www.google.com/maps/place/"+ iArrALGeoX.get(j) + "," + iArrALGeoY.get(j) ),  -9 + 9 * j, -1 + 9 * j, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);//72 80, 81 89, 90 98,
//            }
////            Log.v("aaa", "https://www.google.com/maps/place/"+ iArrALGeoX.get(j) + "," + iArrALGeoY.get(j));
//        }
//        mAnimalAreaItemBinding.mTvAnimalGeo.setMovementMethod(LinkMovementMethod.getInstance());//TextView可點選
//        mAnimalAreaItemBinding.mTvAnimalGeo.setText(pSpannableGeo);
        mDataBinding.mPicVideoGroupIC.mTvGeo.mTvAllZoo.setTextColor(Color.parseColor("#4267b2"))
        mDataBinding.mPicVideoGroupIC.mTvGeo.mTvAllZoo.text = "點擊開啟位置"
        mDataBinding.mPicVideoGroupIC.mTvGeo.mTvAllZoo.setOnClickListener {
            //跳去activity
            // 1. 傳資料 --> Geo.java
            // 2. 將每一組網址存起來，按下按鈕要對應到地圖

//            val iVale = mAlGeo
//            val iIntent = Intent(activity, Geo::class.java)
            val iBundle = Bundle()
            iBundle.putStringArrayList("Geo", mAlGeo)
//            iIntent.putExtras(iBundle)
//            startActivity(iIntent)

            mGoToPageApplication.goToPage(pTargetFragment = GeoFragment(), pBundle = iBundle)
        }
    }

    private fun selectPicShow(
        pGetPicALT: String?,
        pGetPicUrl: String?,
        pTvPicALT: TextView,
        pImgPicURL: ImageView,
    ) {
        //如果沒有圖片就不顯示
        if ((pGetPicUrl == null || pGetPicUrl.isEmpty()) && (pGetPicALT == null || pGetPicALT.isEmpty())) {
            pTvPicALT.visibility = View.GONE
            pImgPicURL.visibility = View.GONE
        } else if (pGetPicALT == null) {
            pTvPicALT.visibility = View.GONE
            try {
                pGetPicUrl?.let { controlPicture(context, it, pImgPicURL) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            pTvPicALT.text = pGetPicALT
            try {
                pGetPicUrl?.let { controlPicture(context, it, pImgPicURL) }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @Throws(Exception::class)
    fun controlPicture(pContext: Context?, pGetPicUrl: String, pImgPicURL: ImageView?) {
        val iStringSplit: String = pGetPicUrl.replace("?", "")
//        Log.v("---aaa--pGetPicUrl---ORI:",pGetPicUrl);
//        Log.v("---aaa--pGetPicUrl---NEW:",iStringSplit);
        Glide.get(pContext!!)
            .registry
            .replace(GlideUrl::class.java,
                InputStream::class.java,
                OkHttpUrlLoader.Factory(RetrofitManager.getSSLOkHttpClient()))
        Glide.with(pContext)
            .asBitmap()
            .load(iStringSplit)
            .error(R.drawable.zoo_logo)
            .placeholder(R.drawable.loading)
            .into(pImgPicURL!!)
    }

    private fun getApi(): ItfDetail? {
        val iBundle = arguments //列表 點擊-->Adapter 資料傳過來  (KeyRawJson=詳細內容, HomePageTitle=標題)
        val iDetailData = DetailData()
        Log.v("aaa", "aaaaa" + iBundle?.getString(Parameter.getInstance().KeyRawJson).toString())
        return if (iBundle != null) {
            when (mTitle) {
                Parameter.getInstance().mKeyAnimal -> {
                    iDetailData.setAnimal(iBundle.getString(Parameter.getInstance().KeyRawJson, ""))
                }
                Parameter.getInstance().mKeyPlant -> {
                    iDetailData.setPlant(iBundle.getString(Parameter.getInstance().KeyRawJson, ""))
                }
                else -> {
                    iDetailData.setArea(iBundle.getString(Parameter.getInstance().KeyRawJson, ""))
                }
            }
        } else null
    }
}