package com.example.zookotlin.roomDataBase

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface DataDao {
    @Query("SELECT * FROM MyData WHERE (Title = :iQueryHomeTitle) AND (nameCh = :iQueryNameCh OR nameEn = :iQueryNameEn) AND clickPosition = :iQueryClickPosition")
    fun queryClickData(
        iQueryHomeTitle: String?,
        iQueryNameCh: String?,
        iQueryNameEn: String?,
        iQueryClickPosition: Int,
    ): MyData?

    //    @Query("SELECT * FROM user WHERE uid IN (:userIds)")
    //    List<MyData> loadAllByIds(int[] userIds);
    //
    //    @Query("SELECT * FROM user WHERE first_name LIKE :first AND " +
    //            "last_name LIKE :last LIMIT 1")
    //    MyData findByName(String first, String last);

    // 預設萬一執行出錯怎麼辦，REPLACE為覆蓋
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertData(users: MyData?)

}