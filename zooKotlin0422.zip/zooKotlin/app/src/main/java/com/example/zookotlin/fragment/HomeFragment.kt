package com.example.zookotlin.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import com.example.zookotlin.AllViewModel
import com.example.zookotlin.R
import com.example.zookotlin.databinding.HomeBinding
import com.example.zookotlin.util.Parameter

class HomeFragment : BaseFragment<HomeBinding, AllViewModel>() {

    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    override val mLayout: Int get() = R.layout.home

    private fun initView() {
        mDataBinding.let {
            it.mBtnHomeGroup.mBtnArea.mBtn.text = Parameter.mKeyArea //館區簡介
            it.mBtnHomeGroup.mBtnAnimalArea.mBtn.text = Parameter.mKeyAnimal //動物簡介
            it.mBtnHomeGroup.mBtnPlantArea.mBtn.text = Parameter.mKeyPlant //植物簡介

            it.mBtnAreaGroup.mBtnIndoorArea.mBtn.text = Parameter.mKeyIndoor //室內區
            it.mBtnAreaGroup.mBtnOutdoorArea.mBtn.text = Parameter.mKeyOutdoor //戶外區
            it.mBtnAreaGroup.mBtnBackToHome.mBtn.text = "簡介"
        }
    }

    @SuppressLint("LongLogTag")
    @Override
    override fun uiInit(pTitle: String?) {
        initView()

        //Toolbar Title設定
        if (pTitle != "") {
            //Title 空的 不顯示 Toolbar
            mDataBinding.mToolbar.title = pTitle
            mDataBinding.mToolbar.visibility = View.VISIBLE
        }

        mDataBinding.mBtnHomeGroup.mBtnArea.mBtn.setOnClickListener {
            mDataBinding.mBtnHomeGroup.root.visibility = View.GONE
            mDataBinding.mBtnAreaGroup.root.visibility = View.VISIBLE
            mGoToPageApplication.mIsOpenInOutDoor = true
        }

        // 動物區
        mDataBinding.mBtnHomeGroup.mBtnAnimalArea.mBtn.setOnClickListener {
            setGoToPageDataAndSend(mDataBinding.mBtnHomeGroup.mBtnAnimalArea.mBtn.text.toString())
        }
        // 植物區
        mDataBinding.mBtnHomeGroup.mBtnPlantArea.mBtn.setOnClickListener {
            setGoToPageDataAndSend(mDataBinding.mBtnHomeGroup.mBtnPlantArea.mBtn.text.toString())
        }
        // 室內區
        mDataBinding.mBtnAreaGroup.mBtnIndoorArea.mBtn.setOnClickListener {
            setGoToPageDataAndSend(mDataBinding.mBtnAreaGroup.mBtnIndoorArea.mBtn.text.toString())
        }
        // 戶外區
        mDataBinding.mBtnAreaGroup.mBtnOutdoorArea.mBtn.setOnClickListener {
            setGoToPageDataAndSend(mDataBinding.mBtnAreaGroup.mBtnOutdoorArea.mBtn.text.toString())
        }

        //館區簡介 Button 設定
        mDataBinding.mBtnAreaGroup.mBtnBackToHome.mBtn.setOnClickListener {
            mDataBinding.mBtnHomeGroup.root.visibility = View.VISIBLE
            mDataBinding.mBtnAreaGroup.root.visibility = View.GONE
            mGoToPageApplication.mIsOpenInOutDoor = false
        }

//        if (mDataBinding.mBtnAreaGroup.root.visibility == View.VISIBLE) {
//            mDataBinding.mBtnHomeGroup.root.visibility = View.VISIBLE
//            mDataBinding.mBtnAreaGroup.root.visibility = View.GONE
//            mGoToPageApplication.mIsOpenInOutDoor = false
//            requireActivity().onBackPressed()
//        }
    }

    private fun setGoToPageDataAndSend(pTitle: String) {
        val iBundle = Bundle()
        iBundle.putString(Parameter.mKeyTitle, pTitle)// 標題
        mGoToPageApplication.goToPage(pTargetFragment = ListFragment(), pBundle = iBundle)
    }

}