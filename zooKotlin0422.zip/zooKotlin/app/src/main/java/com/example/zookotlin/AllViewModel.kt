package com.example.zookotlin

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.zookotlin.data.list.ListData
import com.example.zookotlin.fragment.ListFragment
import java.util.*

open class AllViewModel : ViewModel() {
    private val mAreaList = MutableLiveData<ArrayList<ListData>>()
    private val mFinish = MutableLiveData<Boolean>()
    private var mApiManager: ApiManagerALL? = null

    open fun getListObserver(): MutableLiveData<ArrayList<ListData>> {
        return mAreaList
    }

    open fun getFinish(): MutableLiveData<Boolean> {
        return mFinish
    }

    private val mStringName = StringBuilder()
    private val mStringTitle = StringBuilder()

    private var mCall: ListFragment.Call = object : ListFragment.Call {
        override fun callApi() {
            mApiManager!!.callApiData(mAreaList,
                mStringName.toString(),
                mStringTitle.toString(),
                mFinish) //------Step 4
        }
    }

    //將Bundle 取到的區 傳到API 做Query 抓API裡面資料內容
    open fun sendApi(pName: String?, pTitle: String?): ListFragment.Call? {
        mStringName.delete(0, mStringName.length)
        mStringTitle.delete(0, mStringTitle.length)
        mStringName.append(pName)
        mStringTitle.append(pTitle)
        if (mApiManager == null) {
            mApiManager = ApiManagerALL()
        }
        mApiManager!!.callApiData(mAreaList, pName, pTitle!!, mFinish)// 抓API裡面資料內容
        return mCall
    }

}
