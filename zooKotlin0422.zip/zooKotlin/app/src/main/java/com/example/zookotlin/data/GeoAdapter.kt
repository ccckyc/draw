package com.example.zookotlin.data

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView
import com.example.zookotlin.R
import java.util.ArrayList

class GeoAdapter(private val mDataResult: ArrayList<String>, private var mOnGeoListener: OnGeoListener) :
    RecyclerView.Adapter<GeoAdapter.ViewHolder>() {
//    private val mDataResult = ArrayList<String>()
    var mListData: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.geo_button, parent, false)
        return ViewHolder(view, mOnGeoListener)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(viewHolder: ViewHolder, pPosition: Int) {
        mListData =
            mDataResult[pPosition] //24.9979216,121.5804577    24.9959671,121.5805328    24.9957094,121.5836763    24.9951126,121.5894029

        //
        val iGeoText = pPosition + 1
        viewHolder.mBtnLoc.text = "地點$iGeoText"
        Log.v("aaa", "$pPosition: $mListData")

        //塞資料進去UI
        viewHolder.mBtnLoc.tag = pPosition

        //
        if (mDataResult.size == 1) {
            viewHolder.mBtnLoc.visibility = View.GONE
        }

    }

    override fun getItemCount(): Int {
        return mDataResult.size
    }

    //-----class------
    class ViewHolder(v: View, pOnGeoBtnListener: OnGeoListener) :
        RecyclerView.ViewHolder(v), View.OnClickListener {
        var mBtnLoc: Button = v.findViewById(R.id.mBtnLoc)
        private val mOnGeoBtnListener: OnGeoListener
        override fun onClick(v: View) {
            mOnGeoBtnListener.onGeoBtnClick(adapterPosition)
        }

        init {
            mBtnLoc.setOnClickListener(this)
            mOnGeoBtnListener = pOnGeoBtnListener
        }
    }

    interface OnGeoListener {
        fun onGeoBtnClick(position: Int)
    }

//    init {
//        mDataResult.addAll(pData) //取得到資料塞到Arraylist pData: size = 5
//    }
}
