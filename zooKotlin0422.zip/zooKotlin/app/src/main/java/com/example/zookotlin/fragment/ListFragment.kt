package com.example.zookotlin.fragment

import android.app.ProgressDialog
import android.content.Context
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.zookotlin.AllViewModel
import com.example.zookotlin.R
import com.example.zookotlin.data.ZooAdapter
import com.example.zookotlin.data.list.ListData
import com.example.zookotlin.databinding.ListPageBinding
import com.example.zookotlin.roomDataBase.AppDatabase
import com.example.zookotlin.roomDataBase.MyData
import java.util.ArrayList

class ListFragment : BaseFragment<ListPageBinding, AllViewModel>() {
    private var mFinish = false
    private var mGridLayoutManager: GridLayoutManager? = null
    private var mProgressDialog: ProgressDialog? = null
    private var mBtnChangeBool = false
    private var mZooAdapter: ZooAdapter? = null

    // 2
    private val mCall: Call by lazy {
        object : Call {
            override fun callApi() {
                loading()
                mViewModel.sendApi(null, mDataBinding.mToolbar.title.toString())
            }
        }
    }

    override val mClass: Class<AllViewModel> get() = AllViewModel::class.java
    override val mLayout: Int get() = R.layout.list_page

    override fun uiInit(pTitle: String?) {
        initView()
        clickChangeBtn()
        setViewData()

        //Toolbar title設定
        if (pTitle != "") {
            mDataBinding.mToolbar.title = pTitle
            mDataBinding.mToolbar.visibility = View.VISIBLE
        }
        mDataBinding.mRecyclerView.adapter = ZooAdapter(pTitle) //設定title，再從Adapter傳去給detail

        mDataBinding.mToolbar.setNavigationOnClickListener {
            //在Activity下
            requireActivity().onBackPressed()
        }

//        mCall.callApi() //ori
        callApiNow();
    }

    // 1
    private fun callApiNow() {
//        loading()
        mCall.callApi()
    }


    private fun setViewData() {
//        mViewModel = ViewModelProvider(this)[AllViewModel::class.java]
//        Log.v("aaa", "observe aaa")
        mViewModel.getListObserver().observe(this.viewLifecycleOwner, fun(listData: ArrayList<ListData>) {
                //            Log.v("aaa", "observe bbb")
                if (mDataBinding.mRecyclerView.adapter is ZooAdapter) {
                    mZooAdapter = mDataBinding.mRecyclerView.adapter as ZooAdapter
//                Log.v("aaa", "observe ccc")
                    if (listData != null) {
                        assert(mZooAdapter != null)
//                    Log.v("aaa", "observe ddd")
                        mZooAdapter!!.setData(listData) //抓到APi
                        if (mProgressDialog != null) {
                            mProgressDialog!!.dismiss() //關掉Loading
                        }
                    }
                }
            })

        mViewModel.getFinish().observe(this.viewLifecycleOwner, fun(itFinish: Boolean) {
            mFinish = itFinish!!
        })
    }

    // 切換
    private fun clickChangeBtn() {
        mDataBinding.mBtnChange.setOnClickListener {
            if (!mBtnChangeBool) {
                mGridLayoutManager = GridLayoutManager(activity, 2) //橫的還直的
                mBtnChangeBool = true
            } else {
                mGridLayoutManager = GridLayoutManager(activity, 1) //橫的還直的
                mBtnChangeBool = false
            }
            mZooAdapter?.setBtnChange(mBtnChangeBool)
            mDataBinding.mRecyclerView.layoutManager = mGridLayoutManager
            mDataBinding.mRecyclerView.adapter = mZooAdapter //設定title，再從Adapter傳去給detail
        }
    }

    private fun initView() {
        mGridLayoutManager = GridLayoutManager(activity, 1)
        mDataBinding.mRecyclerView.layoutManager = mGridLayoutManager

        //---- 50筆資料到底抓新的50筆
        mDataBinding.mRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == RecyclerView.SCROLL_STATE_IDLE) { //當前狀態為停止滑動
                    if (!mFinish) {
                        if (!mDataBinding.mRecyclerView.canScrollVertically(1)) { // 到達底部
//                            mCall.callApi()
                            callApiNow()
                        }
                    }
                }
            }
        })
    }

    fun loading() {
        mProgressDialog = ProgressDialog(requireActivity())
        mProgressDialog!!.setMessage("Loading...")
        mProgressDialog!!.setProgressStyle(ProgressDialog.STYLE_SPINNER)
        mProgressDialog!!.show()
        mProgressDialog!!.setCancelable(false)
    }

    fun setRoom(
        pTitle: String?,
        pNameCh: String?,
        pNameEn: String?,
        pPosition: Int,
        pContext: Context?,
    ) {
        Thread {
            val iAppDatabase: AppDatabase? = pContext?.let { AppDatabase.getInstance(it) }
            val iMyData = MyData(pTitle, pNameCh, pNameEn, pPosition) //pAreaTitle,
            iAppDatabase?.getDataDao()?.insertData(iMyData) //pMppDatabase.getDataDao().queryClickData(myData);
        }.start()
    }

    interface Call {
        fun callApi() //到Fragment實作
    }


}