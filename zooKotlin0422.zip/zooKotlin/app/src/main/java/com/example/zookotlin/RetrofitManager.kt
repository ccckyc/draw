package com.example.zookotlin

import android.annotation.SuppressLint
import android.util.Log
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.*
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSession
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object RetrofitManager {
    private var mRetrofitManager: RetrofitManager? = null
//    private var mRetrofit: Retrofit? = null

    fun getInstance(): RetrofitManager? {
        if (mRetrofitManager == null) {
            synchronized(Retrofit::class.java) {
                mRetrofitManager = RetrofitManager
            }
        }
        return mRetrofitManager
    }


    //通過動態代理生成相應的Http請求
    fun <T> createService(service: Class<T>): T {
        return retrofit().create(service)
    }


//    private fun RetrofitManager() { mRetrofit = retrofit() }

    private fun okHttpClient(): OkHttpClient? {
        try {
            return OkHttpClient.Builder()
                .addNetworkInterceptor { chain: Interceptor.Chain -> chain.proceed(chain.request()) }
                .retryOnConnectionFailure(true)
                .readTimeout(100, TimeUnit.SECONDS)
                .connectTimeout(100, TimeUnit.SECONDS)
                .build()
        } catch (e: Exception) {
            Log.v("OkhttpException", "Exception$e")
        }
        return null
    }

    //構建Retrofit
    private fun retrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://data.taipei")
            .addConverterFactory(GsonConverterFactory.create())
            .client(Objects.requireNonNull(okHttpClient()))
            .build()
    }

    @Throws(Exception::class)
    fun getSSLOkHttpClient(): OkHttpClient {
        val trustManager: X509TrustManager = @SuppressLint("CustomX509TrustManager")
        object : X509TrustManager {
            @SuppressLint("TrustAllX509TrustManager")
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
            }

            @SuppressLint("TrustAllX509TrustManager")
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {
            }

            override fun getAcceptedIssuers(): Array<X509Certificate?> {
                return arrayOfNulls(0)
            }
        }
        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, arrayOf<TrustManager>(trustManager), SecureRandom())
        val sslSocketFactory = sslContext.socketFactory
        return OkHttpClient.Builder()
            .sslSocketFactory(sslSocketFactory, trustManager)
            .hostnameVerifier { _: String?, _: SSLSession? -> true }
            .build()
    }

}