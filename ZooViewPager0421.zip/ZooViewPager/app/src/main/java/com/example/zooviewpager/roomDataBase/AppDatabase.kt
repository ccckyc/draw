package com.example.zooviewpager.roomDataBase

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MyData::class], exportSchema = false, version = 1)
abstract class AppDatabase : RoomDatabase() {

    companion object {
        private const val mDbName = "RoomDatabase.db"
        private var mInstance: AppDatabase? = null

        @Synchronized
        fun getInstance(pContext: Context): AppDatabase? {
            if (mInstance == null) {
                mInstance = Room.databaseBuilder(pContext.applicationContext,
                    AppDatabase::class.java,
                    mDbName
                )
                    .fallbackToDestructiveMigration()
                    .build()
            }
            return mInstance
        }
    }

    abstract fun getDataDao(): DataDao?
}