package com.example.zookotlin.util

object Parameter {

    private var mParameter: Parameter? = null

    fun getInstance(): Parameter {
        if (mParameter == null) {
            mParameter = Parameter
        }
        return mParameter!!
    }

    var KeyRawJson = "KeyRawJson"
    var mKeyTitle = "HomePageTitle" //館區、動物、植物介紹title

    var mKeyAnimal = "動物簡介"
    var mKeyPlant = "植物簡介"
    var mKeyArea = "館區簡介"
    var mKeyIndoor = "室內區"
    var mKeyOutdoor = "戶外區"
}