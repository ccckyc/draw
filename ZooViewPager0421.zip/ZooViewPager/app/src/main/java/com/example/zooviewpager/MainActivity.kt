package com.example.zooviewpager

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

// https://developersbreach.com/recyclerview-to-viewpager2-materialviewpager-android/
class MainActivity : AppCompatActivity() {
    private var tabLayout: TabLayout? = null
    private var viewPager2: ViewPager2? = null

    // array for tab labels
    private val labels = arrayOf("動物ㄧ", "動物二", "動物三", "動物四", "動物五",
        "植物ㄧ", "植物二", "植物三", "植物四", "植物五")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()

        // TabLayout和ViewPager的绑定
        TabLayoutMediator(tabLayout!!, viewPager2!!) { tab: TabLayout.Tab, position: Int ->
            tab.text = labels[position]
        }.attach()

        viewPager2!!.setCurrentItem(0, false)
    }

    private fun init() {
        // initialize
        tabLayout = findViewById(R.id.mTab_layout)
        viewPager2 = findViewById(R.id.mView_pager)

        // create adapter instance

        viewPager2!!.adapter = ViewPagerAdapter(this)


        // remove default elevation of actionbar
        supportActionBar!!.elevation = 0f
    }


}