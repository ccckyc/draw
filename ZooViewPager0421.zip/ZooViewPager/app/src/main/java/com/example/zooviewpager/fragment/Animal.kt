package com.example.zooviewpager.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.zooviewpager.AllViewModel
import com.example.zooviewpager.R
import com.example.zooviewpager.data.list.ListData
import java.util.ArrayList

//
class Animal : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?):
            View = inflater.inflate(R.layout.animal_list, container, false)
    lateinit var mViewModel:AllViewModel


    private fun setViewData() {
//        mViewModel.getListObserver().observe(this.viewLifecycleOwner, fun(listData: ArrayList<ListData>) {
//    })
    }

    private val mCall: Call by lazy {
        object : Call {
            override fun callApi() {
                mViewModel.sendApi(null, "動物區")
            }
        }
    }
    private fun callApiNow() {
//        loading()
    mCall.callApi()
    }

    interface Call {
        fun callApi() //到Fragment實作
    }
}