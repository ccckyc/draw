package com.example.zooviewpager

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.bumptech.glide.Glide
import com.example.zookotlin.util.Parameter
import com.example.zooviewpager.data.list.ListData
import com.example.zooviewpager.fragment.Animal
import com.example.zooviewpager.fragment.Area
import com.example.zooviewpager.fragment.Plant
import com.example.zooviewpager.roomDataBase.AppDatabase
import com.example.zooviewpager.roomDataBase.MyData


class ViewPagerAdapter(fragmentActivity: FragmentActivity) :
    FragmentStateAdapter(fragmentActivity) {

    override fun createFragment(position: Int): Fragment {
        when (position) {
            0 -> return Animal() // Animal fragment
            1 -> return Plant() // Plant fragment
            2 -> return Area() // Area fragment
            3 -> return Animal() // Animal fragment
            4 -> return Plant() // Plant fragment
            5 -> return Area() // Area fragment
        }
        return Animal() //Animal fragment
    }

    // return total number of tabs in our case we have 3
    override fun getItemCount(): Int {
        return 6
    }
}


//class ViewPagerAdapter : RecyclerView.Adapter<ViewPagerAdapter.PagerViewHolder>() {
//    private val mDataResult: ArrayList<ListData> = ArrayList<ListData>()
//    private val mArraySelected = ArrayList<Int>()
//    private val mSynchronizedUsed = "aaa"
//    private val mHandler = Handler(Looper.getMainLooper())
//    private var mActivity: AppCompatActivity? = null
//    private var mPosition = 0
//    private val mRunnable = Runnable { changeUi() }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PagerViewHolder {
//        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.all_area_item, parent, false)
//        return PagerViewHolder(itemView)
//    }
//
//    fun setData(pData: ArrayList<ListData>?) {
//        mDataResult.addAll(pData!!) //傳資料到 mDataResult
//        notifyDataSetChanged()
//    }
//    @SuppressLint("NotifyDataSetChanged")
//    private fun changeUi() {
//        notifyDataSetChanged()
//    }
//
//    @SuppressLint("LongLogTag")
//    override fun onBindViewHolder(holder: PagerViewHolder, pPosition: Int) {
////        holder.bindData(mList[position])
//
//        val iListData: ListData = mDataResult[pPosition]
//
//        getRoomQuery(
//            null,
//            iListData.getNameCh(),
//            iListData.getNameEn(),
//            pPosition,
//            holder.itemView.context
//        )
//
//        //圖片有網址的但顯示不出來，做處理
//        val iNewUrl: String = iListData.getPic01Url()!!.replace("?", "")
//
//        Glide.with(holder.mImg.context)
//            .load(iNewUrl)
//            .error(R.drawable.zoo_logo)
//            .placeholder(R.drawable.loading)
//            .into(holder.mImg)
//
//        holder.mTextIndex.text = "" + pPosition
//        holder.mTvNameCh.text = iListData.getNameCh()
//
//        //Area沒有mTvNameEn -->要做判斷if(  length() !=0  )
//        if (iListData.getNameEn()!!.isNotEmpty()) {
//            holder.mTvNameEn.text = iListData.getNameEn() //.toString().replace("\"","")
//        } else {
//            holder.mTvNameEn.visibility = View.GONE
//        }
//        holder.mLayout.setBackgroundResource(R.drawable.layout_item_init_radius) //原本是 0
//
//        //被點擊過呈現的layout樣式
//        if (mArraySelected.contains(pPosition)) {
//            holder.mLayout.setBackgroundResource(R.drawable.layout_item_click_radius)
//        } else {
//            holder.mLayout.setBackgroundResource(R.drawable.layout_item_init_radius)
//        }
//        //點擊下mLayout 做跳頁到 detail
//        holder.mLayout.tag = pPosition
//        holder.mLayout.setOnClickListener { view: View ->
//            if (view.tag != null) {
//                try {
//                    val iId = view.tag.toString()
//                    if (Character.isDigit(iId[0])) {
//                        mPosition = iId.toInt()
//                        mActivity = view.context as AppCompatActivity
//
//
//                        //點擊跳轉到AllDetailFragment()頁面，傳TitleName 給Detail
//                         sendBundleGoOtherPage("動物區")
//
//
////                        ListFragment().setRoom(
////                            mTitle,
////                            iListData.getNameCh(),
////                            iListData.getNameEn(),
////                            pPosition,
////                            view.context
////                        )
//                        Log.v("---aaa---Adapter---mPosition", pPosition.toString() + "," + iListData.getNameCh())
//                        //
//
//                        //點擊過的標記
//                        view.setBackgroundResource(R.drawable.layout_item_click_radius)
//                        mArraySelected.add(mPosition)
//                    }
//                } catch (ignored: Exception) {
//
//                }
//            }
//        }
//    }
////    fun setList(list: List<Int>) {
////        mList = list
////    }
//    override fun getItemCount(): Int {
//        return mDataResult.size
//    }
//
//
//    //	ViewHolder需要繼承RecycleView.ViewHolder
//    class PagerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//
////        private val mTextView: TextView = itemView.findViewById(R.id.tv_text)
////        private var colors = arrayOf("#CCFF99","#41F1E5","#8D41F1","#FF99CC")
////        fun bindData(i: Int) {
////            mTextView.text = i.toString()
////            mTextView.setBackgroundColor(Color.parseColor(colors[i]))
////        }
//
//        var mLayout: LinearLayout = itemView.findViewById(R.id.mLayout)
//        var mImg: ImageView = itemView.findViewById<View>(R.id.mImgAllAreaItem).findViewById(R.id.mImgAllZoo)
//        var mTvNameCh: TextView = itemView.findViewById<View>(R.id.mTvAllAreaItemNameCh).findViewById(R.id.mTvAllZoo)
//        var mTvNameEn: TextView = itemView.findViewById<View>(R.id.mTvAllAreaItemNameEn).findViewById(R.id.mTvAllZoo)
//        var mTextIndex: TextView = itemView.findViewById<View>(R.id.mTvAllAreaItemIndex).findViewById(R.id.mTvAllZoo)
//
//    }
//
//
//    //撈資料庫的
//    private fun getRoomQuery(
//        pHomeTitle: String?,
//        pNameCh: String?,
//        pNameEn: String?,
//        pPosition: Int,
//        pContext: Context?,
//    ) {
//        Thread {
//            //顏色有問題
//            synchronized(mSynchronizedUsed) {
//                val iFindData = mArraySelected.indexOf(pPosition)
//                if (iFindData == -1) {
//                    val iMyData: MyData? = AppDatabase.getInstance(pContext!!)?.getDataDao()?.queryClickData(pHomeTitle, pNameCh, pNameEn, pPosition)
//
//                    if (iMyData != null) {
//                        mArraySelected.add(pPosition)
//                        mHandler.removeCallbacks(mRunnable)
//                        mHandler.postDelayed(mRunnable, 500)
//
//                    }
//                }
//            }
//        }.start()
//    }
//
//
//    //點擊跳轉到Detail頁面，傳TitleName 給Detail
//    private fun sendBundleGoOtherPage(pTitleName: String?) {
//        val iBundle = Bundle()
//        iBundle.putString(Parameter.getInstance().KeyRawJson, mDataResult[mPosition].getRawData())
//        iBundle.putString(Parameter.getInstance().mKeyTitle, pTitleName) //傳給Detail TitleName
//
////        mGoToPageApplication.goToPage(pTargetFragment = DetailFragment(), pBundle = iBundle)
//    }
//}