package com.example.zookotlin.roomDataBase

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "MyData")
class MyData {
    @PrimaryKey(autoGenerate = true) //設置是否使ID自動累加
    var uid = 0

    @ColumnInfo(name = "Title")
    var pTitle: String? = null

    @ColumnInfo(name = "nameCh")
    var pNameCh: String? = null

    @ColumnInfo(name = "nameEn")
    var pNameEn: String? = null

    @ColumnInfo(name = "clickPosition")
    var pPosition = 0

    constructor(pTitle: String?, pNameCh: String?, pNameEn: String?, pPosition: Int) {
        this.pTitle = pTitle
        this.pNameCh = pNameCh
        this.pNameEn = pNameEn
        this.pPosition = pPosition
    }

//    fun getTitle(): String? {
//        return pHomeTitle
//    }
//
//    fun setTitle(pTitle: String?) {
//        pHomeTitle = pTitle
//    }
//
//    fun getNameCh(): String? {
//        return pNameCh
//    }
//
//    fun setNameCh(pNameCh: String?) {
//        this.pNameCh = pNameCh
//    }
//
//    fun getNameEn(): String? {
//        return pNameEn
//    }
//
//    fun setNameEn(pNameEn: String?) {
//        this.pNameEn = pNameEn
//    }
//
//    fun getPosition(): Int {
//        return pPosition
//    }
//
//    fun setPosition(pPosition: Int) {
//        this.pPosition = pPosition
//    }
}