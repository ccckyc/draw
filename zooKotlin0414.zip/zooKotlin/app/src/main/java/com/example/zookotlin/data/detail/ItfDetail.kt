package com.example.zookotlin.data.detail

import com.google.gson.JsonObject

interface ItfDetail {
    fun setData(pAsJsonObject: JsonObject?)
    fun setData(pRawJson: String?)
    fun getNameCh(): String?
    fun getNameEn(): String?
    fun getPic01Url(): String?

    fun isPicEmpty(): Boolean {
        return false
    }

    fun isVideoEmpty(): Boolean {
        return false
    }

    fun isUrlEmpty(): Boolean {
        return false
    }

    fun isLocationEmpty(): Boolean {
        return false
    }


    fun getPic01ALT(): String? {
        return ""
    }

    fun getPic02ALT(): String? {
        return ""
    }

    fun getPic03ALT(): String? {
        return ""
    }

    fun getPic04ALT(): String? {
        return ""
    }

    fun getPic02URL(): String? {
        return ""
    }

    fun getPic03URL(): String? {
        return ""
    }

    fun getPic04URL(): String? {
        return ""
    }

    fun getVedioURL(): String? {
        return ""
    }

    fun getLocation(): String? {
        return ""
    }

    fun getGeo(): String? {
        return ""
    }

    //----- Animal -----//
    fun getABehavior(): String? {
        return ""
    }

    fun getADistribution(): String? {
        return ""
    }

    fun getAClass(): String? {
        return ""
    }

    fun getFamily(): String? {
        return ""
    }


    //----- Area -----//
    fun getEInfo(): String? {
        return ""
    }

    fun getEMemo(): String? {
        return ""
    }

    fun getEUrl(): String? {
        return ""
    }


    //----- Plant -----//
    fun getAlsoKnown(): String? {
        return ""
    }

    fun getBrief(): String? {
        return ""
    }

    fun getFeature(): String? {
        return ""
    }

    fun getGenus(): String? {
        return ""
    }

    fun getFunctionApplication(): String? {
        return ""
    }

}