package com.example.zookotlin.data.detail

interface ViewModelClass<ClassData> {

    val mClass: Class<ClassData>
}