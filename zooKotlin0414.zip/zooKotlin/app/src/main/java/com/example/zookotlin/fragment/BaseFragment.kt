package com.example.zookotlin.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.zookotlin.MyApplication
import com.example.zookotlin.data.detail.ViewModelClass
import com.example.zookotlin.util.Parameter

abstract class BaseFragment<T : ViewDataBinding, VM : ViewModel> : Fragment(), ViewModelClass<VM> {
    private var mTampDataBinding: T? = null
    protected val mDataBinding: T get() = mTampDataBinding!!
    protected val mViewModel: VM by lazy { ViewModelProvider(this)[mClass] }

    protected var mTitle = ""
    abstract val mLayout: Int
    lateinit var mGoToPageApplication: MyApplication


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
//        mDataBinding -> AllAreaRecyclerviewBinding
        mViewModel
        mGoToPageApplication = requireActivity().application as MyApplication
        mGoToPageApplication.setFragmentManager(requireActivity().supportFragmentManager)

//      mViewModel = ViewModelProvider(this).get(AllViewModel::class.java) as VM
        val iData = DataBindingUtil.inflate<ViewDataBinding>(inflater, mLayout, container, false)
        mTampDataBinding = iData as T
        return iData?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getBundle()

        val fm = parentFragmentManager //        getBackStackEntryCount() 返回總數量

        for (entry in 0 until fm.backStackEntryCount) {
            Log.v("aaa",
                "BaseFragment ----- Count ----- = " + fm.getBackStackEntryAt(entry).id.toString())
        }

        uiInit(mTitle)
    }

    //取到 點擊bundle傳來的TitleName
    @SuppressLint("LongLogTag")
    protected open fun getBundle() {
        val iBundle = arguments
        if (iBundle != null) {
            //點節Home按鈕才會傳Bundle
            mTitle = iBundle.getString(Parameter.getInstance().mKeyHomePageTitle).toString() //館區簡介
//            Log.v("aaa", "BaseFragment Title = $mTitle")
        }
//        else if (mGetFcmTitle !== "" && mGetFcmTitle != null) {
//            mTitle = when (mGetFcmTitle) {
//                "動物簡介" -> Parameter.getInstance().mKeyAnimal
//                "植物簡介" -> Parameter.getInstance().mKeyPlant
//                "戶外區" -> Parameter.getInstance().mKeyOutdoor
//                "室內區" -> Parameter.getInstance().mKeyIndoor
//                else -> ""
//            }
//        }
        else {
            mTitle = ""
        }
    }


    abstract fun uiInit(pTitle: String?)
}