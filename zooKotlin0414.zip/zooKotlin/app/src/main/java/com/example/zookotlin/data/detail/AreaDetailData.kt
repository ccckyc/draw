package com.example.zookotlin.data.detail

import com.example.zookotlin.data.list.ListData

class AreaDetailData : ListData() {
    init {
        typeArea()
    }

    override fun getEInfo(): String? {
        return getValue("E_Info")
    }

    override fun getEMemo(): String? {
        return getValue("E_Memo")
    }

    override fun getEUrl(): String? {
        return getValue("E_URL")
    }

    override fun getGeo(): String? {
        return getValue("E_Geo")
    }

    override fun isPicEmpty(): Boolean {
        return getPic01Url()?.isEmpty() == true && getPic02URL()?.isEmpty() == true && getPic03URL()?.isEmpty() == true && getPic04URL()?.isEmpty() == true
    }

    override fun isVideoEmpty(): Boolean {
        return getVedioURL() == null || getVedioURL()!!.isEmpty()
    }

    override fun isLocationEmpty(): Boolean {
        return getLocation() == null || getLocation()!!.isEmpty()
    }
}
