package com.example.zookotlin

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.example.zookotlin.databinding.ActivityMainBinding
import com.example.zookotlin.fragment.DetailFragment
import com.example.zookotlin.fragment.HomeFragment
import com.example.zookotlin.fragment.ListFragment
import com.example.zookotlin.util.Parameter


class MainActivity : AppCompatActivity() {
    private var mActivityMainBinding: ActivityMainBinding? = null

    private var mGetFcmTitle: String? = ""
    private var mGetFcmDetail: String? = ""
    private var mGetAllDetailData: String? = ""


    //    private lateinit var mGoToPageApplication: GoToPageApplication
    companion object {
        val mGoToPageApplication: MyApplication by lazy {
            mTampSaveGoToPageApplication!!
        }
        private var mTampSaveGoToPageApplication: MyApplication? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

//        getBundle(intent)

        // 先抓有沒有點擊通知
        fakeFcmData()

        if (savedInstanceState == null) {

            mTampSaveGoToPageApplication = application as MyApplication
            mGoToPageApplication.setFragmentManager(this.supportFragmentManager)

            mGoToPageApplication.goToPage(pTargetFragment = HomeFragment())
//            supportFragmentManager.beginTransaction()
//                .setReorderingAllowed(true)
//                .add(
//                    R.id.fragment_container_view,
//                    HomeFragment::class.java, null,
//                    HomeFragment::class.java.simpleName
//                )
//                .commit()

            // 判斷有沒有點擊 Broadcast ，點擊後才會有值
            if (intent.extras != null) {

//                val iHandler = Handler()
//                val iRunnable = Runnable {
//                  onNewIntent(intent)
//                }
//                iHandler.removeCallbacks(iRunnable)
//                iHandler.postDelayed(iRunnable, 500)

                Handler(Looper.getMainLooper()).postDelayed({
                    // onNewIntent 跳太快，要讓他延遲一下下
                    onNewIntent(intent)
                }, 500)
            }

            Log.v("--aaa--", "intent.extras  = " + intent.extras)
        }
    }

    private fun getBundle(pIntent: Intent) {
        mGetFcmTitle = pIntent.getStringExtra("fcmTitleData") //FCM 標題
        mGetFcmDetail = pIntent.getStringExtra("fcmDetailData") //FCM 內容
        mGetAllDetailData = pIntent.getStringExtra("fcmCallApiAllDetail") //FCM 取得Call Api內容

        Log.v("aaa", "onCreate get iGetFcmTitle  0  = $mGetFcmTitle")
        Log.v("aaa", "onCreate get iGetFcmDetail  0  = $mGetFcmDetail")
        Log.v("aaa", "onCreate get iGetAllDetailData  0  = $mGetAllDetailData")
    }

    // FCM接收
    private fun fakeFcmData() {
        val iArrayTitle = ArrayList<String>()
//        iArrayTitle.add("植物簡介")
//        iArrayTitle.add("植物簡介")
        iArrayTitle.add("動物簡介")
        iArrayTitle.add("動物簡介")
//        iArrayTitle.add("室內區")
//        iArrayTitle.add("戶外區")

        val iArrayName = ArrayList<String>()
//        iArrayName.add("大花紫薇")
//        iArrayName.add("九芎")
        iArrayName.add("大貓熊")
        iArrayName.add("國王企鵝")
//        iArrayName.add("Name 1")
//        iArrayName.add("Name 2")

        val iArrayIndex = ArrayList<String>()
        iArrayIndex.add("0")
        iArrayIndex.add("1")


        val iFcmFakeTest: FCMFake = FCMFake().setContext(this)
        object : Thread() {
            override fun run() {
                super.run()
                for (i in 0..1) {
                    //假推播
                    iFcmFakeTest.callApiData2(iArrayName[i],
                        iArrayTitle[i],
                        iArrayIndex[i]) //iArrayName[i],iArrayIndex[i]
                }
            }
        }.start()
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)

//        var iiFragment: Fragment? = null
//
//        for (iFragment in supportFragmentManager.fragments) {
//            val iTag = iFragment.tag
//            Log.v("aaa", "iTag = " + iTag + ",isHidden " + iFragment.isHidden)
//            if (iTag != null) {
//                if (iTag != "com.bumptech.glide.manager") {
//                    iiFragment = iFragment
//                }
//            }
//        }

//        val iGetFcmTitle = intent.getStringExtra("fcmTitleData") //FCM 標題
//        val iGetFcmDetail = intent.getStringExtra("fcmDetailData") //FCM 內容
//        val iGetAllDetailData = intent.getStringExtra("fcmCallApiAllDetail") //FCM 取得Call Api內容

        getBundle(intent)

        Log.v("aaa", "getFragments    =" + supportFragmentManager.fragments.size)
//        Log.v("aaa", "iiFragment tag=" + iiFragment.getTag());
//        Log.v("aaa", "mGetAllDetailData = " + mGetAllDetailData);


        if (mGetFcmDetail == "") {
            val iBundle = Bundle()
            iBundle.putString(Parameter.getInstance().mKeyHomePageTitle, mGetFcmTitle)
            Log.v("aaa", "onNewIntent mGetFcmTitle    = $mGetFcmTitle")

            mGoToPageApplication.goToPage(pTargetFragment = ListFragment(), pBundle = iBundle)

//            val iAllFragment = ListFragment()
//            iAllFragment.arguments = iBundle
//
//            val mHomeFragmentManager = supportFragmentManager
//            mHomeFragmentManager.beginTransaction()
//                .add(
//                    R.id.fragment_container_view,
//                    iAllFragment,
//                    iAllFragment::class.java.simpleName
//                )
//                .setReorderingAllowed(true) //
//                .hide(iiFragment!!)
//                .addToBackStack(null) // name can be null
//                .commit()
        } else if (mGetFcmDetail != null && mGetAllDetailData != null) {
            val iBundle = Bundle()
            iBundle.putString(Parameter.getInstance().mKeyHomePageTitle, mGetFcmTitle)
            iBundle.putString(Parameter.getInstance().KeyRawJson, mGetAllDetailData)

            mGoToPageApplication.goToPage(pTargetFragment = DetailFragment(), pBundle = iBundle)

//            val iAllDetailFragment = DetailFragment()
//            iAllDetailFragment.arguments = iBundle
//
//            val mHomeFragmentManager = supportFragmentManager
//            if (iiFragment != null) {
//                mGoToPageApplication.goToNextPage(iAllDetailFragment, null)
//                mHomeFragmentManager.beginTransaction()
//                    .add(
//                        R.id.fragment_container_view,
//                        iAllDetailFragment,
//                        iAllDetailFragment::class.java.simpleName
//                    )
//                    .setReorderingAllowed(true)
//                    .hide(iiFragment)
//                    .addToBackStack(null) // name can be null
//                    .commit()
//            }
        } else {
            mGoToPageApplication.goToPage(pTargetFragment = HomeFragment())
        }
    }

    //手機本身的 返回
    @RequiresApi(api = Build.VERSION_CODES.O)
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        super.onKeyDown(keyCode, event)
        return mGoToPageApplication.goToPage(pKeyCode = keyCode, pEvent = event)

//        if (keyCode == KeyEvent.KEYCODE_BACK) {
//            if (supportFragmentManager.fragments.size != 0) {
//                for (ix in supportFragmentManager.fragments) {
//                    Log.v("aaa", "ix=" + ix.tag)
//                    Log.v("aaa", "aaaaaaaaa"+ix.isHidden)
//                    if (ix.tag == HomeFragment::class.java.simpleName && !ix.isHidden) {
//                        return false
//                    }
//                }
//            }
//        }
//        return true
    }
}

