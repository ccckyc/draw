package com.example.zookotlin

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class GettingNotificationData : BroadcastReceiver() {
    override fun onReceive(pContext: Context?, pIntent: Intent?) {
//        val mGetFcmTitle: String = pIntent?.getStringExtra("fcmTitleData").toString()
//        val mGetFcmDetail: String = pIntent?.getStringExtra("fcmDetailData").toString()
//        val mGetAllDetailData: String = pIntent?.getStringExtra("fcmCallApiAllDetail").toString()


//        Log.v("aaa", "BroadcastReceiver pTitle=$mGetFcmTitle")
//        Log.v("aaa", "BroadcastReceiver pTitle=$mNotifyClick")


        val iIntent = Intent(pContext, MainActivity::class.java)
        iIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        iIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        pIntent?.extras?.let { iIntent.putExtras(pIntent) }
        pContext?.startActivity(iIntent)
    }

}
