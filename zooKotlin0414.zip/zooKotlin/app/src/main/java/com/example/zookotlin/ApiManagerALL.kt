package com.example.zookotlin

import android.annotation.SuppressLint
import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.zookotlin.data.list.ListData
import com.example.zookotlin.util.Parameter
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class ApiManagerALL {
    private var mIndex = 0
    private val mLimit = 50
    private var mDataIsFinish = false
    private var mLock = false


    fun callApiData(pList: MutableLiveData<ArrayList<ListData>>, pName: String?, pTitle: String, pFinish: MutableLiveData<Boolean>) {
        Log.v("aaa", "--------- IN ---------")
        if (mDataIsFinish || mLock) {
            return
        }
        synchronized(this) { mLock = true }
        Log.v("aaa", "-------- SEND ---------")
        val iService = RetrofitManager.getInstance()!!.createService(APIService::class.java)
        val iCall: Call<JsonObject?>? = when (pTitle) {
            Parameter.getInstance().mKeyPlant -> {
                iService.getPlant(pName, mLimit, mIndex)
            }
            Parameter.getInstance().mKeyAnimal -> {
                iService.getAnimal(pName, mLimit, mIndex)
            }
            else -> {
                Log.v("aaa", "pTitle = $pTitle")
                iService.getArea(pTitle, mLimit, mIndex) //&q &limit &offset

            }
        }
        iCall!!.enqueue(object : Callback<JsonObject?> {
            @SuppressLint("LongLogTag")
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                val iDataResult = ArrayList<ListData>()
                //抓API
                val iJsonObject: JsonObject = Objects.requireNonNull(response.body())!!.getAsJsonObject("result")
                val iResults: JsonArray = iJsonObject.getAsJsonArray("results")
                // Log.v("---aaa---ViewModel---callApi---iResults", String.valueOf(iResults));
                for (i in 0 until iResults.size()) {
                    val iListData = ListData()
                    when (pTitle) {
                        Parameter.getInstance().mKeyPlant -> {
                            iListData.typePlant()
                        }
                        Parameter.getInstance().mKeyAnimal -> {
                            iListData.typeAnimal()
                        }
                        else -> {
                            iListData.typeArea()
                        }
                    }
                    iListData.setData(iResults[i].asJsonObject)
                    iDataResult.add(iListData)
                }
                if (iDataResult.size == mLimit) {
                    mIndex += mLimit
                } else {
                    mDataIsFinish = true
                }
                pFinish.postValue(mDataIsFinish)

                //Lock
                object : Thread() {
                    override fun run() {
                        super.run()
                        try {
                            sleep(500)
                            mLock = false
                        } catch (e: InterruptedException) {
                            e.printStackTrace()
                        }
                    }
                }.start()
                pList.postValue(iDataResult)
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {}
        })
    }
}
