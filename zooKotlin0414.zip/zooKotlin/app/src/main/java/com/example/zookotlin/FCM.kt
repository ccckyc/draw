package com.example.zookotlin

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.zookotlin.data.list.ListData
import com.example.zookotlin.util.Parameter
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class FCM : FirebaseMessagingService() {
//    private var mIndex = 0
//    private var mLimit = 50
    var mCallApiAllDetail = ""

    override fun onNewToken(pToken: String) {
        super.onNewToken(pToken)
        Log.d("MyFirebaseMessaging", "裝置Token: $pToken")
    }

    // FCM接收
    override fun onMessageReceived(pRemoteMessage: RemoteMessage) {
        super.onMessageReceived(pRemoteMessage)
        Log.d("MyFirebaseMessaging", "onMessageReceived: " + pRemoteMessage.data)

        //--- Call API ---//
        if (pRemoteMessage.data["Detail"] != "" || pRemoteMessage.data["Detail"] != null) {
            Log.v("---aaa---FCM---callApi", "--- IN ---")
            callApiData2(pRemoteMessage.data["Detail"]!!,
                pRemoteMessage.data["Title"]!!,
                pRemoteMessage.data["Id"]!!)
            Log.v("---aaa---FCM---callApi", "--- OUT ---")
        }
    }

    private fun createNotification(pName: String, pTitle: String) {
        Log.v("aaa", "--- createNotification ---")
        //檢查手機版本是否支援通知
        val iChannelId = "ChannelId"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(iChannelId,
                "com.example.zooKotlin",
                NotificationManager.IMPORTANCE_DEFAULT)
            val manager = getSystemService(
                NotificationManager::class.java)!!
            manager.createNotificationChannel(channel)
        }
        val pendingIntent = sendToBroadCast(pName, pTitle)


        //建置通知欄位的內容
        val iNotificationCompatBuilder = NotificationCompat.Builder(this, iChannelId)
            .setSmallIcon(R.drawable.zoo_logo) //icon
            .setContentTitle(pTitle)
            .setContentText(pName)
            .setAutoCancel(true) //點到後是否自動消失
            .setPriority(NotificationCompat.PRIORITY_HIGH) //                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pendingIntent)


        //把通知發出去
        val iTime = System.currentTimeMillis().toInt() //就可累加通知
        Log.v("aaa", "iTime = $iTime")
        val iNotificationManagerCompat = NotificationManagerCompat.from(this)
        iNotificationManagerCompat.notify(iTime, iNotificationCompatBuilder.build())
    }

    @SuppressLint("UnspecifiedImmutableFlag")
    private fun sendToBroadCast(pName: String, pTitle: String): PendingIntent {
        Log.v("aaa", "FCM pTitle = $pTitle")
        Log.v("aaa", "FCM pName = $pName")
        val intent = Intent(this, GettingNotificationData::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val iBundle = Bundle()
        iBundle.putString("fcmTitleData", pTitle)
        iBundle.putString("fcmDetailData", pName)
        iBundle.putString("fcmCallApiAllDetail", mCallApiAllDetail)

        Log.v("aaa---fcm-bundle", iBundle.toString())
        intent.putExtras(iBundle)
        return PendingIntent.getBroadcast(this, System.currentTimeMillis().toInt(), intent, 0)
    }


    private fun callApiData2(pName: String, pTitle: String, pIndex: String) {
        val iIndex = pIndex.toInt() //0
        val iLimit = 1 //50

        val iService = RetrofitManager.getInstance()!!.createService(APIService::class.java)
        val iCall: Call<JsonObject?>? = when (pTitle) {
            Parameter.getInstance().mKeyPlant -> {
                iService.getPlant(pName, iLimit, iIndex)
            }
            Parameter.getInstance().mKeyAnimal -> {
                iService.getAnimal(pName, iLimit, iIndex)
            }
            else -> {
                iService.getArea(pName, iLimit, iIndex) //&q &limit &offset
            }
        }
        iCall!!.enqueue(object : Callback<JsonObject?> {
            @SuppressLint("LongLogTag")
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                val iDataResult: ArrayList<ListData> = ArrayList<ListData>()
                //抓API
                Log.v("aaa", "--- enqueue ---")
                val iJsonObject: JsonObject =
                    Objects.requireNonNull(response.body())!!.getAsJsonObject("result")
                val iResults: JsonArray = iJsonObject.getAsJsonArray("results")
                Log.v("aaa", "--- out 1 ---")
                mCallApiAllDetail = ""
//                if (iResults != null) {
                for (i in 0 until iResults.size()) {
                    val iListData = ListData()
                    when (pTitle) {
                        Parameter.getInstance().mKeyPlant -> {
                            iListData.typePlant()
                            Log.v("aaa", "--- out 2 ---")
                        }
                        Parameter.getInstance().mKeyAnimal -> {
                            iListData.typeAnimal()
                        }
                        else -> {
                            iListData.typeArea()
                        }
                    }
                    iListData.setData(iResults[i].asJsonObject)
                    iDataResult.add(iListData)
                    mCallApiAllDetail = iDataResult[i].getRawData().toString()
//                    }
                }
                createNotification(pName, pTitle)
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {}
        })
    }
}