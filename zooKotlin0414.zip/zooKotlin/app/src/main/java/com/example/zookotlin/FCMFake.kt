package com.example.zookotlin

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.zookotlin.data.list.ListData
import com.example.zookotlin.util.Parameter
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class FCMFake {
    private var mContext: Context? = null
    private var mCallApiAllDetail: String? = null


    fun setContext(pContext: Context?): FCMFake {
        mContext = pContext
        return this
    }


    fun createNotification(pName: String, pTitle: String) {
        Log.v("aaa", "--- createNotification ---")
        //檢查手機版本是否支援通知
        val iChannelId = "ChannelId"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                iChannelId,
                "com.example.zooKotlin",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = mContext!!.getSystemService(
                NotificationManager::class.java
            )!!
            manager.createNotificationChannel(channel)
        }
        val pendingIntent = sendToBroadCast(pName, pTitle)


        //建置通知欄位的內容
        val iNotificationCompatBuilder = NotificationCompat.Builder(mContext!!, iChannelId)
            .setSmallIcon(R.drawable.zoo_logo) //icon
            .setContentTitle(pTitle)
            .setContentText(pName)
            .setAutoCancel(true) //點到後是否自動消失
            .setPriority(NotificationCompat.PRIORITY_HIGH) //                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pendingIntent)


        //把通知發出去
        val iTime = System.currentTimeMillis().toInt() //就可累加通知
        Log.v("aaa", "iTime = $iTime")
        val iNotificationManagerCompat = NotificationManagerCompat.from(mContext!!)
        iNotificationManagerCompat.notify(iTime, iNotificationCompatBuilder.build())
    }


    @SuppressLint("UnspecifiedImmutableFlag")
    private fun sendToBroadCast(pName: String, pTitle: String): PendingIntent {
        val intent = Intent(mContext, GettingNotificationData::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)

        val iBundle = Bundle()
        iBundle.putString("fcmTitleData", pTitle)
        iBundle.putString("fcmDetailData", pName)
        iBundle.putString("fcmCallApiAllDetail", mCallApiAllDetail)
//        iBundle.putBoolean("fcmNotifyClick", false)

        Log.v("aaa---fcmFake-bundle", iBundle.toString())
//        Log.v("aaa---fcmFake-bundle", "pTitle=$pTitle, pName=$pName, mCallApiAllDetail=$mCallApiAllDetail")

        intent.putExtras(iBundle)
        return PendingIntent.getBroadcast(mContext, System.currentTimeMillis().toInt(), intent, 0)
    }

//    private fun openActivity(pName: String, pTitle: String): PendingIntent? {
//        val intent = Intent(mContext, MainActivity::class.java)
//        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
//        val iBundle = Bundle()
//        iBundle.putString("fcmTitleData", pTitle)
//        iBundle.putString("fcmDetailData", pName)
//        iBundle.putString("fcmCallApiAllDetail", mCallApiAllDetail)
//        intent.putExtras(iBundle)
//        return PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
//    }

    fun callApiData2(pName: String, pTitle: String, pIndex: String) {
        val mIndex = pIndex.toInt()
        val mLimit = 1
        val iService = RetrofitManager.getInstance()!!.createService(APIService::class.java)
        val iCall: Call<JsonObject?>? = when (pTitle) {
            Parameter.getInstance().mKeyPlant -> {
                iService.getPlant(pName, mLimit, mIndex)
            }
            Parameter.getInstance().mKeyAnimal -> {
                iService.getAnimal(pName, mLimit, mIndex)
            }
            else -> {
                iService.getArea(pName, mLimit, mIndex) //&q &limit &offset
            }
        }
        iCall!!.enqueue(object : Callback<JsonObject?> {
            @SuppressLint("LongLogTag")
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                val iDataResult: ArrayList<ListData> = ArrayList<ListData>()
                //抓API
                Log.v("aaa", "--- enqueue ---")
                val iJsonObject: JsonObject =
                    Objects.requireNonNull(response.body())!!.getAsJsonObject("result")
                val iResults: JsonArray = iJsonObject.getAsJsonArray("results")
                mCallApiAllDetail = ""
                for (i in 0 until iResults.size()) {
                    val iListData = ListData()
                    when (pTitle) {
                        Parameter.getInstance().mKeyPlant -> {
                            iListData.typePlant()
                        }
                        Parameter.getInstance().mKeyAnimal -> {
                            iListData.typeAnimal()
                        }
                        else -> {
                            iListData.typeArea()
                        }
                    }
                    iListData.setData(iResults[i].asJsonObject)
                    iDataResult.add(iListData)
                    mCallApiAllDetail = iDataResult[i].getRawData().toString()


                }
                createNotification(pName, pTitle)
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {}
        })
    }
}