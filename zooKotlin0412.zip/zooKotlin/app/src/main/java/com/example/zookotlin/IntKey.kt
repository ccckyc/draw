package com.example.zookotlin

object IntKey {

    val mGoToList by lazy {
        1
    }


    val mGoToDetail by lazy {
        2
    }

    val mGoToOthers by lazy {
        -1
    }
}