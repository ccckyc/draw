package com.example.zookotlin.data.list

import com.example.zookotlin.data.detail.ItfDetail
import com.google.gson.JsonObject
import org.json.JSONException
import org.json.JSONObject

open class ListData : ItfDetail {
    private var mAsJsonObject: JSONObject? = null
    private var keyPicUrl: String? = null
    private var keyNameCh: String? = null
    private var keyNameEn: String? = null

    open fun getRawData(): String? {
        return mAsJsonObject.toString()
    }

    open fun typeAnimal() {
        keyPicUrl = "A_Pic01_URL"
        keyNameCh = "\uFEFFA_Name_Ch"
        keyNameEn = "A_Name_En"
    }

    open fun typePlant() {
        keyPicUrl = "F_Pic01_URL"
        keyNameCh = "\uFEFFF_Name_Ch"
        keyNameEn = "F_Name_En"
    }

    open fun typeArea() {
        keyPicUrl = "E_Pic_URL"
        keyNameCh = "E_Name"
    }


    protected fun getValue(pKey: String?): String? {
        return try {
            mAsJsonObject?.getString(pKey)
        } catch (e: JSONException) {
            e.printStackTrace()
            ""
        }
    }

    override fun getNameCh(): String? {
        return getValue(keyNameCh)
    }

    override fun getNameEn(): String? {
        return getValue(keyNameEn)
    }

    override fun getPic01Url(): String? {
        return getValue(keyPicUrl)
    }

    override fun setData(pAsJsonObject: JsonObject?) {
        try {
            mAsJsonObject = JSONObject(pAsJsonObject.toString())
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }

    override fun setData(pRawJson: String?) {
        try {
            mAsJsonObject = JSONObject(pRawJson)
        } catch (e: JSONException) {
            e.printStackTrace()
        }
    }
}